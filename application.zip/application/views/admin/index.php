<?php 
    require "section/header.php";
    require "pages/".$page.".php";
    require "section/footer.php";
    echo $page;
?>